from flask import Flask, render_template_string
import pandas as pd

app = Flask(__name__)

data = pd.read_excel("Updated_Student_Performance_Data.xlsx", engine="openpyxl")

@app.route("/")
def home():
    total_students = len(data)
    avg_percentage = round(data["Percentage"].mean(), 2)
    class_counts = data["Class"].value_counts().to_dict()

    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Student Analytics Dashboard</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background: linear-gradient(to right, #1f4037, #99f2c8);
                margin: 0;
                padding: 0;
            }
            .container {
                width: 90%;
                margin: auto;
                padding: 20px;
                text-align: center;
            }
            h1 {
                color: white;
                margin-bottom: 30px;
            }
            .cards {
                display: flex;
                justify-content: space-around;
                flex-wrap: wrap;
                margin-bottom: 30px;
            }
            .card {
                background: white;
                padding: 20px;
                width: 250px;
                border-radius: 10px;
                box-shadow: 0 4px 8px rgba(0,0,0,0.2);
                margin: 10px;
            }
            .card h2 {
                margin: 0;
                color: #1f4037;
            }
            .card p {
                font-size: 22px;
                font-weight: bold;
                margin: 10px 0 0 0;
            }
            .class-section {
                background: white;
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            }
            ul {
                list-style-type: none;
                padding: 0;
            }
            li {
                padding: 8px;
                font-size: 18px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📊 Student Performance Analytics Dashboard</h1>

            <div class="cards">
                <div class="card">
                    <h2>Total Students</h2>
                    <p>{{total}}</p>
                </div>

                <div class="card">
                    <h2>Average Percentage</h2>
                    <p>{{average}}%</p>
                </div>
            </div>

            <div class="class-section">
                <h2>Students Per Class</h2>
                <ul>
                    {% for class_name, count in classes.items() %}
                    <li>{{class_name}} : {{count}}</li>
                    {% endfor %}
                </ul>
            </div>
        </div>
    </body>
    </html>
    """, total=total_students, average=avg_percentage, classes=class_counts)

if __name__ == "__main__":
    app.run(debug=True)